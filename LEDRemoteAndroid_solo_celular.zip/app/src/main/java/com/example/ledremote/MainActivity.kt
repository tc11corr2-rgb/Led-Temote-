package com.example.ledremote

import android.app.Activity
import android.os.Bundle
import android.hardware.ConsumerIrManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var ir: ConsumerIrManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ir = getSystemService(CONSUMER_IR_SERVICE) as ConsumerIrManager

        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(IrBridge(), "AndroidIR")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")

        if (!ir.hasIrEmitter()) {
            Toast.makeText(this, "Este dispositivo no informa un emisor IR disponible.", Toast.LENGTH_LONG).show()
        }
    }

    inner class IrBridge {
        @JavascriptInterface
        fun hasEmitter(): Boolean = ir.hasIrEmitter()

        // Los patrones están intencionalmente vacíos hasta identificar los códigos
        // exactos del control original. No se deben inventar: podrían no funcionar.
        @JavascriptInterface
        fun transmit(command: String): String {
            if (!ir.hasIrEmitter()) return "NO_IR"
            val pattern = IrCodes.patterns[command] ?: return "CODE_MISSING"
            if (pattern.isEmpty()) return "CODE_MISSING"
            return try {
                ir.transmit(38_000, pattern)
                "SENT"
            } catch (e: Exception) {
                "ERROR: ${e.message ?: "falló la transmisión"}"
            }
        }
    }
}

private object IrCodes {
    // Cada patrón es una secuencia de duraciones en microsegundos:
    // marca, espacio, marca, espacio... a 38 kHz.
    // Completar con datos medidos/verificados para ESTE mando.
    val patterns: Map<String, IntArray> = mapOf(
        "ON" to intArrayOf(),
        "OFF" to intArrayOf(),
        "RED" to intArrayOf(),
        "GREEN" to intArrayOf(),
        "BLUE" to intArrayOf(),
        "WHITE" to intArrayOf(),
        "BRIGHT_UP" to intArrayOf(),
        "BRIGHT_DOWN" to intArrayOf(),
        "FLASH" to intArrayOf(),
        "STROBE" to intArrayOf(),
        "FADE" to intArrayOf(),
        "SMOOTH" to intArrayOf(),
        "COLOR_1" to intArrayOf(), "COLOR_2" to intArrayOf(),
        "COLOR_3" to intArrayOf(), "COLOR_4" to intArrayOf(),
        "COLOR_5" to intArrayOf(), "COLOR_6" to intArrayOf(),
        "COLOR_7" to intArrayOf(), "COLOR_8" to intArrayOf(),
        "COLOR_9" to intArrayOf(), "COLOR_10" to intArrayOf(),
        "COLOR_11" to intArrayOf(), "COLOR_12" to intArrayOf()
    )
}
